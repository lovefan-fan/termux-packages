# BitKeeper completion
# adapted from code by  Bart Trojanowski <bart@jukie.net>

_comp_cmd_bk()
{
    local cur prev words cword comp_args
    _comp_initialize -- "$@" || return

    local BKCMDS=$(bk help topics 2>/dev/null |
        _comp_awk '/^  bk/ { print $2 }')

    _comp_compgen -- -W "$BKCMDS"
    _comp_compgen -a filedir

} &&
    complete -F _comp_cmd_bk bk
