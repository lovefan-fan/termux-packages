#!/data/data/com.yaohuo/files/usr/bin/sh

echo "$@"
