if [ ! -f /data/data/com.yaohuo/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.yaohuo/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.yaohuo/files/home/.termux
	cp /data/data/com.yaohuo/files/usr/share/examples/termux/termux.properties /data/data/com.yaohuo/files/home/.termux/
fi
