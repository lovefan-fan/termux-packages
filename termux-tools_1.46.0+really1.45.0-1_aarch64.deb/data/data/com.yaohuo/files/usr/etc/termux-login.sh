##
## This script is sourced by /data/data/com.yaohuo/files/usr/bin/login before executing shell.
##
